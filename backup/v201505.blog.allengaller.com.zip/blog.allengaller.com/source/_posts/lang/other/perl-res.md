title: "Docker Resources"
date: 2015-03-01 16:46:12
tags:
- resource
categories:
- cloud
- docker

---

### Perl

__Link__:

__Read__:

[Perl语言入门(影印版)(第6版)]  
[Perl最佳实践(中文版)]  
