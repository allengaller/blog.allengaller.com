title: "Cx Resources"
date: 2015-04-02 16:46:12
tags:
- resource
categories:
- languages
- cx

---
## CxList

__Link__:

__Read__:

[C程序设计语言(英文版)(第2版)]  
[C Primer Plus][] | [][]  
[C专家编程]  
[你必须知道的495个C语言问题]  
[C语言详解(第6版)]  
[C语言程序设计:现代方法(第2版)]  
[一站式学习C编程(升级版)]  

[C++ Primer Plus][] | [][]
[C++ Primer][] | [][]
[Essential C++(注释版)]

- C Programming FAQs 你必须知道的495个C语言问题
- C Programming: A Modern Approach(2th) C语言程序设计现代方法
- C Problem Solving and Program Design in C(6th) C语言详解
- Linux C编程实战
- C语言深度解剖:解开程序员面试笔试的秘密
- C Primer Plus
- C++ Primer Plus(5th)

C++:

    <C++ Primer>
C:

    <C Primer Plus>
