title: "Web Server Resources"
date: 2015-03-01 16:46:12
tags:
- resource
categories:
- server
- web

---

__Link__:

- [linuxjournal](http://www.linuxjournal.com)

__Read__:

	- [构建高可用Linux服务器](http://book.douban.com/subject/6873681/)
	- [鸟哥的Linux私房菜:基础学习篇(第三版)]  
	- [深入Linux内核架构]  
	- [嵌入式系统Linux内核开发实战指南(ARM平台)]  
	- [专业嵌入式软件开发:全面走向高质高效编程]  

	- Unix环境高级编程
	- Unix网络编程 卷1 套接字联网API
	- Unix网络编程 卷2 进程间通信

	- 一站式學習C編程

	- 图灵的《软件调试的艺术》
	- Person的《Windows并发编程指南》
	- 华中科大《多核计算与程序设计》
	- Addison Wesley的《PCI系统结构》
	- 代码整洁之道
	- 鸟哥的Linux私房菜:基础学习篇(3th)
	-  Linux 指令语法辞典
	- Linux 命令详解词典

__Virtualization__:

	- Xen虚拟化技术
	- 计算系统虚拟化：原理与应用
	- 系统虚拟化:原理与实现
	- 虚拟机
	- 编译原理 教材


__Security__:
https://www.funnysafe.com/

## Tool

- [Meld](http://meldmerge.org/) Differ
- [Terminator]() Console

# PaaS
- [时速云](https://www.tenxcloud.com)
