title: "Docker Resources"
date: 2015-03-01 16:46:12
tags:
- resource
categories:
- cloud
- docker

---

## Zen
[西藏生死书]
[当下的力量]
[一个瑜伽行者的自传]
[冥想]
[生命之书]
[正见:佛陀的证悟]
[圣严法师著作精品集]
[禅修入门:虚云]
[生命之书:365天的静心冥想:克里希那穆提,胡因梦]
[遇见未知的自己:张德芬]
[心的导引:宁静安住的禅修之道:萨姜米庞仁波切]
[活出生命的意义]

## Yoga
[瑜伽之道]
[瑜伽气功与冥想:蕙兰]
READING [瑜伽哲学十四讲:身心和谐之道][14-yoga] | [笔记][14-yoga-notes]
[呼吸的科学]  
[巴坦加里的瑜伽经:沙吉难陀]
[内观:William Hart]

[14-yoga]: http://book.douban.com/subject/1962491/
[14-yoga-notes]: http://book.douban.com/subject/1962491/

禅修 汇总
## 门户
- http://fo.sina.com.cn/
- http://www.foyuan.net/
- http://www.bskk.com/

http://fo.sina.com.cn/zt/fhjt/index.shtml
