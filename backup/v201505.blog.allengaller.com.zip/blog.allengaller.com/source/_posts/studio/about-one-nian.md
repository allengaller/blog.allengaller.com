title: "One Nian 一念 产品设计"
date: 2015-04-13 13:46:12
tags:
- about
categories:
- studio
- ZenX

---

# One Nian

## BRD


## MRD

## PRD
![](http://ag-qiniu.u.qiniudn.com/zenx_one-nian-prd.png)

## Reference:
鸡血模块:
[茴香](http://huixiang.im/)
[一经典](http://www.1jingdian.com/)
[句子迷](http://www.juzimi.com/)

番茄钟模块:

