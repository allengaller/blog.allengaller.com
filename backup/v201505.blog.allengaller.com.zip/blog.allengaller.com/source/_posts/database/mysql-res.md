title: "MySQL Resources"
date: 2015-03-01 16:46:12
tags:
- resource
categories:
- database
- mysql

---

# Plan

1. SQL基础
2. MySQL基础话题
3. MySQL高级话题

# Link

# Doc
## 数据库

- MySQL基础+调优
- MongoDB基础+调优
- ORM：[Medoo](http://medoo.in/)
- PDO

# Read

- [高性能MySQL](http://book.douban.com/subject/4241826/)
- [高可用MySQL](http://book.douban.com/subject/6847455/)
- [MySQL必知必会](http://book.douban.com/subject/3354490/)
