title: "Docker Resources"
date: 2015-03-01 16:46:12
tags:
- resource
categories:
- cloud
- docker

---

# Life

## Run
- [虎扑跑步](http://run.hupu.com/)
- [跑步天堂](http://bbs.runbible.cn/forum.php)

- [网易跑步课堂](http://www.tudou.com/programs/view/cegazbgBFOg/)

## Read

## Music

## Movie

## Game

### Roll Master

### Mindcraft
http://minecraft-zh.gamepedia.com/%E6%95%99%E7%A8%8B/%E8%8F%9C%E9%B8%9F%E6%89%8B%E5%86%8C

### 生化危机

### 星际争霸

### CS


Wishlist
__Life:__

- Peace
- Health

__Work:__

- NEXT Project

__Publish__:

- Docker in Action

__Gear:__

- Xiaomi TV
- Xiaomi Note +
- Xiaomi Box 2+

- XBox
- Macbook Air

- iPhone 4s
- iPad
- iPod Classic
- iPod Nano
- Kindle 3

- Palm Treo
- HTC Touch HD 2
- Sony Ericsson 300C

__Kits:__

- Herman Miller Embody
- HHKB Pro 2
- Beats Pill 2
