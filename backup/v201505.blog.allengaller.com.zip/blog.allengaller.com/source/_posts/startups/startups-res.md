title: "Startups Resources"
date: 2015-03-01 16:46:12
tags:
- resource
categories:
- startups
- startups

---

# Link

- [Product Hunt](http://www.producthunt.com/)
- http://gimletmedia.com/show/startup/episodes/
- http://xiangmu.cyzone.cn/
- http://www.demo8.com/

__创业服务平台__
AngelCrunch/天使汇  |  创投圈  |  创业津梁  |  LinkStartup  |  AngelList  |

__创业资讯__
创之  |  36氪  |  快鲤鱼  |  TC中文  |  IT桔子  |  Crunchbase  |  Venture Beat |  Startupdigest  |  PandoDaily  |
__科技资讯__
- [TECH2IPO/创见](http://tech2ipo.com/)
新浪科技
腾讯科技
虎嗅  |  
钛媒体  |  
极客公园  |  
雷锋网  |  
猎云网  |  
LiveSino  |  
爱范儿  |
PingWest  |
互联网分析沙龙

__硬件科技资讯__
雷科技  |  
奇笛网
__实物众筹平台__
点名时间  |  
Kickstarter  |  
Indiegogo  |  
众筹网  |  
追梦网  |  
中国梦网  |
__股权众筹平台__
天使汇快速合投  |  
大家投  |  
原始会  |  
氪加  |  
众投邦
__国内风投机构__
红杉资本  |  
软银中国  |  
IDG资本 |  
经纬中国  |  
真格基金  |  
创新工场  |  
腾讯投资  |  
启明创投  |  
PreAngel  |
金沙江创投  |  
顺为基金  |  
鼎晖投资  |  
凯鹏华盈  |  
鼎晖投资  |  
戈壁投资  |  
北极光创投  |  
紫金科创  |
__创业公开课__
精益创业  |  
Peter Thiel  |  
YC Blog  |  
FirstRound  |  
Startup Management
__招聘平台__
大街网  |  
拉勾网  |  
猎聘网  |  
周伯通  |  
卧龙阁  |  
内推网  |

__创业工具服务__
合伙人招募  缘创派  |
服务聚合  阿里云聚无线  |
语音PaaS服务 容联云通讯  |
CRM 服务 麦客  | 纷享销客  |
消息推送  极光推送  |  信鸽  |  小米推送
大数据处理 阿里云OTPS  |
支付SDK Ping++ |
企业应用加速方案 网宿APPA |
__孵化器+加速器__
北京  100X | i黑马  |  创新工场  | VenturesLab  |  厚德创新谷  |  清华科技园  |  瀚海孵化器  |  3W孵化器
上海  中国加速  |  苏河汇  |  创智天地  |  起点创业营  |  创翼天地  |  新单位  |  新车间  |  联合创业办公社  |  创智天地
广东  广州联炬  |  创新谷Innovalley
杭州  传媒梦工场  |  赛博创业工场  |
成都  创业场
美国  Y Combinator  |  TechStars  | DreamIt Ventures  |  500 Startups  |  TechNexus  |  Kicklabs  |  AngelPad  |  LaunchPad LA  |  Excelerate Labs  |  REDI Cincinnati  |  Capital Factory |  ER Accelerator
__创业咖啡__
车库咖啡  |  3W咖啡  |  Beta咖啡  |  福云咖啡  |  创业影院  |  必帮咖啡  |  IT茶会  |  Demo咖啡  |  极客咖啡
__开放平台__
淘宝系  淘宝开放平台  |  淘宝无线开放平台  |  阿里巴巴开放平台  |
电商系  京东开放平台  |  360开放平台大全  |  360手机开放平台  |  豆瓣API
门户系  微博开放平台  |  网易开放平台  |  搜狐开放平台  |  搜狐视频开放平台  |  人人网开放平台  |  开心网开放平台
腾讯系  腾讯开放平台  |  腾讯无线开放平台  |  腾讯应用中心开放平台  |  微信开放平台  |  腾讯地图API  |  搜狗推广API  |  搜狗地图API
百度系  百度开发者中心  |  百度手机开放平台  |  百度开放平台  |  百度云开放平台  |  百度地图API  |  百度移动游戏开放平台  |  百度推广API
移动系  中国移动开放平台  |  联通开发者  |  小米开发者平台  |
视频系  优酷API  |  土豆开放平台  |  大众点评开发者  |  谷歌地图API  |  迅雷下载开放引擎
海外系  Google   |  Facebook 开放平台  |  Twitter 开放平台  |  快递100开放平台
__域名注册服务__
Godaddy  |  name.com  |  eNom  |  中国万网  |  新网  |  新网互联  |  商务中国  |  35互联  |  中国频道  |  中资源  |  美橙互联  |  时代互联
中国数据  |  西部数码  |  有孚网络  |  爱名网  |  尊米网  |  易名中国  |  金名网  |  易介网  |  域名城  |  拍米网
__域名解析服务__
国内 DNSPod  |  DNS.LA  |  EDNS  |  百度加速乐  |  360网站卫士
国外 ZoneEdit  |  HE.NET  |  FreeDNS  |  afraid  |  GoDaddy  |  NameCheap  |  CloudFlare
__云服务__
亚马逊AWS  |  VMware  |  App Engine  |  盛大云计算  |  阿里云  |  新浪云  | 腾讯云  |  又拍云  |  七牛云  |  UCloud  |
网宿科技  |  蓝汛  |  快网  |  蓝芒科技  |  新世纪数据中心
__快速建站服务__
Discuz  |  WordPress  |  PHPWind  |  PHPcms  |  ECshop商店系统  |  最土团购系统  |  近乎SNS社区软件  |  方维
__站点统计功能__
Google Analytics  |  Google Trends  |  百度统计  |  量子统计  |  CNZZ  |  超级监控  |  Alexa
__移动应用统计__
App Annie  |  友盟  |  Talking Data  |  苹果应用汇  |  百度移动应用统计  |  PlayData  |
__广告联盟__
阿里妈妈  |  百度联盟  |  携程分销联盟  |  宇初网络  |  印象码  |  亿起发  |  成果联盟  |  Discuz!联盟  |  网易联盟  |  易推广  |  域名停靠  |  搜狗联盟  |  快车下载联盟  |  迅雷联盟  |  亿告  |  人人游戏联盟  |  有道联盟  |  A5广告联盟  |  领克特  |  多麦联盟  |  乐视联盟  |  金山网盟  |  360效果联盟  |  太极圈  |  点告网盟  |  Google AdSense  |  Amazon Associates  |  Commission Junction  |  LinkShare  |  Clickbank  |  Pixazza  |  Ebay Partner Network

__Startups Dev Tool__

- [devstore](http://www.devstore.cn)
- [乌云](http://www.wooyun.org)

__Starupts Notes__

- [notes](http://ffc2015.startupnotes.org/)
- [startupvitamins](http://www.startupvitamins.com)
- [producthunt](http://www.producthunt.com)
- [zenfounder](http://zenfounder.com)
- [startuptalks](http://startuptalks.tv)
- [morningreader](http://morningreader.com)
- [创之](http://chuang.pro/)

- [link](http://chuang.pro/startup-guide)

# MOOC
- [斯坦福大学公开课：如何创业](http://open.163.com/special/opencourse/startup.html)

# Found

- [红杉](http://www.sequoiacap.cn/en/)

# EC

- 派代: http://www.paidai.com/

- http://www.buzzfeed.com/

# 建站

- 快站: [http://www.kuaizhan.com/](http://www.kuaizhan.com/)

# 体感类

# 开源硬件
- [openhw](http://www.openhw.org)
- [硬蛋](http://www.ingdan.com/)

- [openwrt](https://openwrt.org/)
- [openwrt中文](http://www.openwrt.org.cn/)

# 社交类


# 多媒体
- http://www.smule.com/

# 奇葩

- [全栈技能树](http://ag-qiniu.u.qiniudn.com/sk.jpg)
