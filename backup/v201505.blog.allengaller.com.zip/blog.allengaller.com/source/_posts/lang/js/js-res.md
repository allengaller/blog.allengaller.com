title: "Javasciprt Resources"
date: 2015-02-01 16:46:12
tags:
- resource
categories:
- languages
- javascript

---

__Link__:

## 知识点
- https://platform.html5.org/

## 加速
- http://www.bootcdn.cn/
- [淘宝NPM](http://npm.taobao.org/)
http://diveintohtml5.info/

http://foundation.zurb.com/apps/

http://www.appgyver.com/

http://ionicframework.com/

http://gulpjs.com/

https://angularjs.org/
__Read__:
[Javascript权威指南][js-guide] | [笔记][js-guide-notes]
[JavaScript征途]
[jQuery基础教程]

[js-guide]: http://book.douban.com/subject/2228378/
[js-guide-notes]: http://book.douban.com/subject/2228378/

Javascript编程能力
1. 基本语法
0909 0910

2. 常用函数

3. jQuery
<jQuery必知必会>

4. 常用工具
0910 RequireJS

5. 常用框架
6.
