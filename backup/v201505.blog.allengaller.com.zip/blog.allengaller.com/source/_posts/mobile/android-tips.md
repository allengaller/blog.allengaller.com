title: "Android Tips"
date: 2015-03-01 16:46:12
tags:
- tips
categories:
- mobile
- android

---

# Roadmap

Java basic
Env setup
Basic facts
UI
System
Data storage
Hyper Coding
Android testing
Android project
