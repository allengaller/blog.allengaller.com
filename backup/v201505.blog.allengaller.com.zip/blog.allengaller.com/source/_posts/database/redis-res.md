title: "Docker Resources"
date: 2015-03-01 16:46:12
tags:
- resource
categories:
- cloud
- docker

---
## Redis
http://redisdoc.com/en/latest
http://www.redisbook.com/en/latest
